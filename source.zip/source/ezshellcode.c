#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>

void init()
{
    setvbuf(stderr, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);
    setvbuf(stdin, 0, 2, 0);
    void *addr = mmap((void *)0x114514000, 0x1000,
                      PROT_READ | PROT_WRITE | PROT_EXEC,
                      MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
    if (addr == MAP_FAILED)
    {
        perror("mmap failed");
        exit(1);
    }
}

void vuln()
{
    char *buf = (char *)0x114514000;
    printf("----- Welcome to the pwn lab 1 -----\nYou code :\n");
    read(0, buf, 0x1000);
    ((void (*)())buf)();
}

int main()
{
    init();
    vuln();
    printf("You are not a hacker, you are a loser!\n");
    return 0;
}