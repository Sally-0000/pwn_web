#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void init()
{
    setvbuf(stderr, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);
    setvbuf(stdin, 0, 2, 0);
}

void gift()
{
    system("/bin/sh");
}

void vuln()
{
    char buf[64];
    printf("how to leak the canary?\n");
    printf("You name: %s\n", buf);
    read(0, buf, 0x40);
    printf("You name: %s\n", buf);
    read(0, buf, 0x60);
}

int main()
{
    init();
    vuln();
    printf("You are not a hacker, you are a loser!\n");
    return 0;
}