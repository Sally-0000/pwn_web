from pwn import *
context.log_level = 'debug'
r=process('./PIE')
gdb.attach(r)
r.interactive()
