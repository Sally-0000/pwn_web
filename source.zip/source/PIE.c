#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void init()
{
    setvbuf(stderr, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);
    setvbuf(stdin, 0, 2, 0);
}

void backd00r()
{
    system("/bin/sh");
}

int main();

void vuln()
{
    char buf[64];
    printf("a special gift: %p\n",&main);
    printf("You account: \n");
    read(0, buf, 0x100);
    printf("You password: %s\n", buf);
    read(0, buf, 0x100);
}

int main()
{
    init();
    vuln();
    printf("You are not a hacker, you are a loser!\n");
    return 0;
}