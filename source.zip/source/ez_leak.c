#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void init()
{
    setvbuf(stderr, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);
    setvbuf(stdin, 0, 2, 0);
}

void gift()
{
    printf("It is eazy for you\n");
    system("/bin/sh");
}

void vuln()
{
    char buf[64];
    printf("-----Welcome to the pwn-----\n");
    printf("You name: %s\n", buf);
    gets(buf);
}

int main()
{
    init();
    vuln();
    printf("You are not a hacker, you are a loser!\n");
    return 0;
}