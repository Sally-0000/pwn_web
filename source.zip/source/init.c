#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <malloc.h>

int *heap_list[16];
int heap_list_size[16];

void init() {
    setvbuf(stdout,0,2,0);
    setvbuf(stderr,0,2,0);
    setvbuf(stdin,0,2,0);
    memset(heap_list, 0, sizeof(heap_list));
    memset(heap_list_size, 0, sizeof(heap_list_size));
}   

void menu() {
    printf("1. Add a new note\n");
    printf("2. Delete a note\n");
    printf("3. Edit a note\n");
    printf("4. Check the note\n");
    printf("5. Exit\n");
    puts("Your choice: ");
}

void add_note()
{
    for(int i=0; i<16; i++)
    {
        if(!heap_list[i])
        {    
            char size[8];
            char *note;
            while(1)
            {
                printf("Size: ");
                read(0, size, 4);
                heap_list_size[i] = atoi(size);
                if(heap_list_size[i] <=0)
                {
                    puts("invalid size");
                    continue;
                }
                else
                {
                    note = (char *)malloc(heap_list_size[i]);
                    heap_list[i] = (int *)note;
                    break;
                }
                if(heap_list_size[i] > 0x1500) 
                {
                    puts("Size is too big!");
                    exit(1);
                }
            }

            // char buffer[size_num];
            // memset(buffer, 0, sizeof(buffer));
            if(!note)
            {
                puts("Memory allocation failed!");
                exit(2);
            }
            printf("Content: ");
            read(0, note, heap_list_size[i]);
            printf("Note %d added successfully!\n",i);
            // off by null
            // strcpy(note, buffer);
            // off by one
            // read(0, buffer, size_num+1);
            break;
        }
        else if(i >= 15)
        {
            puts("Heap is full!");
            break;
        }
    }
}

void delete_note()
{
    char buf[8];
    int index_num;
    printf("Index: ");
    read(0, buf, 4);
    index_num = atoi(buf);
    if(index_num < 0 || index_num > 15)
    {
        puts("Invalid index");
        return;
    }
    if(heap_list[index_num])
    {
        free(heap_list[index_num]);
        // heap_list[index_num] = NULL; // UAF
        // heap_list_size[index_num] = 0;//uaf
        puts("Note deleted successfully!");
    }
    else
    {
        puts("Free corrupted!");
        exit(3);
    }
}

void edit_note()
{
    puts("Please enter the index of the note you want to edit:");
    char buf[8];
    int index_num;
    read(0, buf, 4);
    index_num = atoi(buf);
    if(index_num < 0 || index_num > 15|| heap_list[index_num] == NULL)
    {
        puts("Invalid index");
        return;
    }
    else
    {
        size_t current_size = malloc_usable_size(heap_list[index_num]);
        puts("Please enter the new content:");
        read(0, heap_list[index_num], current_size-1);
        ((char *)heap_list[index_num])[current_size-1] = '\0';
    }
    // 堆溢出
    // else
    // {
    //     puts("Please enter the length of item name:");
    //     char size[8];
    //     int size_num;
    //     read(0, size, 4);
    //     size_num = atoi(size);
    //     if (size_num <= 0)
    //     {
    //     puts("Invalid size");
    //     return;
    //     }
    //     puts("Please enter the new content:");
    //     read(0, heap_list[index_num], size_num);
    //     puts("Note edited successfully!");
    // }

    // 堆溢出2
    //     else
    //     {
    //         char ch;
    //         int offset = 0;
    //         puts("Please enter the new content:");
    //         while (1)
    //         {
    //             if (read(0, &ch, 1) <= 0)
    //                 break;
    //             if (ch == '\n')
    //                 break;
    //             ((char *)heap_list[index_num])[offset++] = ch;
    //         }
    //         puts("Note edited successfully!");
    //     }
    // }
    //
    //    off-by-one:
    //     else
    //     {
    //      puts("Please enter the new content:");
    //      read(0, heap_list[index_num], size_num+1);
    //      puts("Note edited successfully!");
    //      }  

    //    off-by-null:
        // else
        // {
        //  puts("Please enter the new content:");
        //  read(0, heap_list[index_num], heap_list_size[index_num]);
        //  ((char *)heap_list[index_num])[heap_list_size[index_num]] = '\0';
        //  puts("Note edited successfully!");
        // }
}

void check_note()
{
    puts("Please enter the index of the note you want to edit:");
    char buf[8];
    int index_num;
    read(0, buf, 4);
    index_num = atoi(buf);
    if (index_num < 0 || index_num > 15|| heap_list[index_num] == NULL)
    {
        puts("Invalid index");
        return;
    }
    else
    {
        printf("Note %d: %s\n", index_num, (char *)heap_list[index_num]);
    }
}



int main()
{
    init();
    char choice[8];
    printf("Welcome to the note management system!\n");
    printf("Gift %p\n", &puts);
    while (1)
    {
        menu();
        read(0, choice, 8);
        switch (atoi(choice))
        {
        case 1:
            add_note();
            break;
        case 2:
            delete_note();
            break;
        case 3:
            edit_note();
            break;
        case 4:
            check_note();
            break; 
        case 5:
            puts("Bye!");
            exit(0);
            break;
        case  6:
            for(int i=0; i<16; i++)
            {
                if(heap_list[i])
                {
                    printf("heap_list[%d]: %p\n", i, heap_list[i]);
                    // printf("heap_list_size[%d]: %d\n", i, heap_list_size[i]);
                }
            }
            break;
        default:
            puts("Invalid choice");
            break;
        }
    }
    return 0;
}

