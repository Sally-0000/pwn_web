#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void init()
{
    setvbuf(stderr, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);
    setvbuf(stdin, 0, 2, 0);
}

void vuln()
{
    char buf[64];
    printf("The basic ret2libc\n");
    read(0, buf, 0x100);
}

int main()
{
    init();
    vuln();
    return 0;
}
